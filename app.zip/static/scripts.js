// You can add interactivity if needed
console.log("Calculator script loaded");